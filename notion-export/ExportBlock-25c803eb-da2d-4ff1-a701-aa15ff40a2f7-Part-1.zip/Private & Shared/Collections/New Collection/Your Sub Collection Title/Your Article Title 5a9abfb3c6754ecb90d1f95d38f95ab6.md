# Your Article Title

Article Description: A description for your article
Last Updated: August 4, 2021
Published: Yes
Suggested: Yes

This is an [**HelpKit**](https://www.helpkit.so/) **sample** help article. This is the place where you provide valuable information to your customers. You can:

- create content
- add questions & answers
- add tutorial videos
- or whatever else you wish ✨

## How to do something big

<aside>
💡 Maybe use a callout box to emphesize certain areas?

</aside>

### Some important side information

In order to read this article you have to follow the steps of this neat numbered list:

1. Open your **`eyes` 👀**
2. Navigate to your Notion app
3. Read this sample article
4. Come up with something *much more helpful* than this sample  

### Use images or videos to visually highlight things

![Take a look at one our own help article images](Your%20Article%20Title/Screenshot_2021-09-08_at_14.18.40.png)

Take a look at one our own help article images

---

👋 Curious about all the Notion blocks you can use with HelpKit? 

Check out our [**test suite here**](https://support.helpkit.so/Working-with-Notion-Docs/crG31kiLtd678d3PdJXvfj/Which-Notion-block-types-are-supported/2qK2E1KRvDMdsmHYi625Xd).