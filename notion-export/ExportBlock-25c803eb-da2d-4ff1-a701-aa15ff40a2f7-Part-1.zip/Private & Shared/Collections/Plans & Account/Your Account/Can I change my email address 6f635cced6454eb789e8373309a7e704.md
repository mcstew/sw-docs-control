# Can I change my email address?

Article Description: How to change your email
Last Updated: January 8, 2026
Published: Yes
Suggested: No

Sure! To change your email address you’ll need to reach out to us from the email currently associated with your Sudowrite account, as well as the email that you’d like us to switch your account over to.

You can email us here: [hi@sudowrite.com](mailto:hi@sudowrite.com)