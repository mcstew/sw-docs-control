# Can I track my credit usage?

Article Description: Yes, you sure can
Last Updated: January 8, 2026
Published: Yes
Suggested: No

Your credit usage can be tracked through the Recent Activity log, accessible via the Settings menu. Just click the (⚙️) gear icon in the upper right of Sudowrite, and select **Show Recent Activity** from the Settings panel. This log provides a detailed list of the features you've used most recently and the credits consumed by each, helping you monitor and manage your credit use.