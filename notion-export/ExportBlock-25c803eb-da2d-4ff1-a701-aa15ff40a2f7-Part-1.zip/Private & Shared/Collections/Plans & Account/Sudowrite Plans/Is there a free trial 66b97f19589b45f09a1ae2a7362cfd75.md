# Is there a free trial?

Article Description: Spoiler: Yes
Last Updated: January 7, 2026
Published: Yes
Suggested: No

Yes! You can get started with a free trial, after which you will need an active plan to use any of Sudowrite’s features. The free trial is not time-limited—you’re free to tinker and experiment with Sudowrite’s features until you exhaust the 10,000 trial credits included.

Oh, and don’t worry—you’ll always be able to access and export your documents, even without an active plan!