# Discord Server

Article Description: Chat with friendly, forward-thinking authors like yourself
Last Updated: March 22, 2024
Published: Yes
Suggested: No

Sudowrite has a community Discord server available, where you can connect with other curious and friendly, forward-thinking authors.

**👉 [Join the community Discord server here now: https://discord.gg/sudowrite](https://discord.gg/sudowrite)**

We know that not everyone is on Discord, and new tools can be overwhelming—so we hosted a Discord open house to try and demystify both the tool, and the unique setup of our server. It’s hosted on our YouTube, but you can watch it right here.

[https://youtu.be/ZwgPm9IdLvg?feature=shared](https://youtu.be/ZwgPm9IdLvg?feature=shared)