# Community Contributor Awards

Article Description: How we give back to All Star community members.
Published: No
Suggested: No

If you participate in our community Discord server, you may have noticed that Staff and Ambassadors occasionally react to a message with a gold star. ⭐️ That’s our way of acknowledging noteworthy contributions—and as a thank you, we like to offer those community members **10,000** bonus credits.

There’s no limit to the number of contributor awards you can receive. In fact, if you receive five gold stars you will join the ranks of the Community All Stars, earning an All Stars role within the Discord server.

Received your first **Nice post!!** notification from Sudobot in the server? Complete this form to claim your credits

(You only have to complete this form the very first time you’re awarded.)

[https://airtable.com/embed/appzYmPFcz9Wxzn0X/pagssProH5t9onzm8/form](https://airtable.com/embed/appzYmPFcz9Wxzn0X/pagssProH5t9onzm8/form)