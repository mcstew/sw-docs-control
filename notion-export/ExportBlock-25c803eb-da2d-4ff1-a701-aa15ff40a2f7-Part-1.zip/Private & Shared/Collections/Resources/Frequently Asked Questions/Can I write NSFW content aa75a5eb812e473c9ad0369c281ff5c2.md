# Can I write NSFW content?

Published: No
Suggested: No

Yes, NSFW & erotica are allowed! The only content we don't allow on the platform is any sexual content that involves minors. To be clear, erotica involving adults is A-okay!