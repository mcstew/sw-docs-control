# Where do I submit feedback or feature requests?

Last Updated: March 22, 2024
Published: Yes
Suggested: No

Have some feedback for us, or a feature you’d love to see in Sudowrite? You can suggest a feature (or upvote an existing suggestion) at [**our Feedback page here**](https://feedback.sudowrite.com/). That’s also where you can find out changelog.

If you’re already a member of our community Discord server, we also have a **#feedback-and-ideas** channel there where you can flag these requests to our attention.

Your feedback and suggestions are super helpful as we chart the future of Sudowrite, and we super appreciate them. Keep them coming!